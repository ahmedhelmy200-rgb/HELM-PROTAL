import * as React from "react"
import * as RadioGroupPrimitive from "@radix-ui/react-radio-group"
import { Circle } from "lucide-react"
import { cn } from "@/lib/utils"
const RadioGroup = React.forwardRef(({ className, ...props }, ref) => <RadioGroupPrimitive.Root className={cn("grid gap-2", className)} {...props} ref={ref} />)
const RadioGroupItem = React.forwardRef(({ className, ...props }, ref) => <RadioGroupPrimitive.Item ref={ref} className={cn("aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow", className)} {...props}><RadioGroupPrimitive.Indicator className="flex items-center justify-center"><Circle className="h-3.5 w-3.5 fill-primary" /></RadioGroupPrimitive.Indicator></RadioGroupPrimitive.Item>)
export { RadioGroup, RadioGroupItem }
