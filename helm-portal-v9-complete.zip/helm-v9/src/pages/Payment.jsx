import React, { useState, useEffect, useCallback } from 'react'
import { supabase } from '@/integrations/supabase/client'
import { base44 } from '@/api/base44Client'
import { getInvoiceTotals } from '@/lib/invoiceMath'
import { parsePaymentToken } from '@/lib/paymentLinks'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { loadStripe } from '@stripe/stripe-js'
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from '@stripe/react-stripe-js'
import {
  CreditCard, Shield, CheckCircle2, AlertCircle,
  Loader2, Building2, Phone, Mail, Receipt,
  Landmark, ArrowLeft, Copy, Banknote,
} from 'lucide-react'

// ── ألوان Stripe تتناسب مع theme النظام ─────────────────────────────────
const STRIPE_APPEARANCE = {
  theme  : 'night',
  variables: {
    colorPrimary       : '#3b82f6',
    colorBackground    : '#060e2a',
    colorText          : '#e2e8f0',
    colorDanger        : '#ef4444',
    fontFamily         : 'Cairo, system-ui, sans-serif',
    spacingUnit        : '5px',
    borderRadius       : '10px',
  },
}

// ── مكوّن نموذج الدفع بالبطاقة ────────────────────────────────────────────
function CardPaymentForm({ clientSecret, invoice, totals, onSuccess }) {
  const stripe   = useStripe()
  const elements = useElements()
  const [error,      setError]      = useState('')
  const [processing, setProcessing] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!stripe || !elements) return
    setProcessing(true)
    setError('')
    try {
      const { error: submitErr } = await elements.submit()
      if (submitErr) { setError(submitErr.message); setProcessing(false); return }

      const { error: confirmErr } = await stripe.confirmPayment({
        elements,
        clientSecret,
        confirmParams: {
          return_url: `${window.location.origin}/Payment?paid=1&inv=${invoice.id}`,
        },
        redirect: 'if_required',
      })

      if (confirmErr) {
        setError(confirmErr.message)
        setProcessing(false)
      } else {
        onSuccess()
      }
    } catch (err) {
      setError(err.message)
      setProcessing(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5" dir="rtl">
      <div className="bg-muted/30 rounded-2xl p-4 border border-border">
        <PaymentElement
          options={{
            layout: 'tabs',
            wallets: { applePay: 'auto', googlePay: 'auto' },
          }}
        />
      </div>

      {error && (
        <div className="flex items-start gap-2 p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm">
          <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
          {error}
        </div>
      )}

      <Button
        type="submit"
        disabled={!stripe || processing}
        className="w-full h-12 text-base font-bold gap-2 bg-primary hover:bg-primary/90"
      >
        {processing ? (
          <><Loader2 className="h-5 w-5 animate-spin" />جارٍ معالجة الدفع…</>
        ) : (
          <><CreditCard className="h-5 w-5" />دفع {totals.remaining.toLocaleString('ar')} {invoice.currency || 'د.إ'}</>
        )}
      </Button>

      <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
        <Shield className="h-3.5 w-3.5 text-green-500" />
        دفع آمن ومشفر بـ Stripe — بياناتك البنكية لا تُخزَّن لدينا
      </div>
    </form>
  )
}

// ── مكوّن التحويل البنكي ──────────────────────────────────────────────────
function BankTransferSection({ invoice, officeSettings, totals }) {
  const [copied, setCopied] = useState(null)

  const copy = (text, key) => {
    navigator.clipboard?.writeText(text).catch(() => {})
    setCopied(key)
    setTimeout(() => setCopied(null), 2000)
  }

  const hasBank = officeSettings?.bank_name || officeSettings?.iban || officeSettings?.bank_account

  if (!hasBank) return (
    <div className="text-center py-4 text-sm text-muted-foreground">
      لم يتم إعداد بيانات التحويل البنكي بعد.
    </div>
  )

  return (
    <div className="space-y-3" dir="rtl">
      <p className="text-sm text-muted-foreground text-center">
        يرجى تحويل المبلغ على البيانات التالية وإرسال إثبات الدفع
      </p>

      <div className="bg-muted/30 rounded-2xl border border-border p-4 space-y-3">
        {officeSettings.bank_name && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">البنك</span>
            <span className="font-semibold text-foreground">{officeSettings.bank_name}</span>
          </div>
        )}
        {officeSettings.bank_account && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">رقم الحساب</span>
            <div className="flex items-center gap-2">
              <span className="font-mono font-semibold text-foreground text-sm">{officeSettings.bank_account}</span>
              <button onClick={() => copy(officeSettings.bank_account, 'acc')} className="text-primary hover:text-primary/80">
                <Copy className="h-3.5 w-3.5" />
              </button>
              {copied === 'acc' && <span className="text-xs text-green-500">✓</span>}
            </div>
          </div>
        )}
        {officeSettings.iban && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">IBAN</span>
            <div className="flex items-center gap-2">
              <span className="font-mono font-semibold text-foreground text-xs tracking-wider">{officeSettings.iban}</span>
              <button onClick={() => copy(officeSettings.iban, 'iban')} className="text-primary hover:text-primary/80">
                <Copy className="h-3.5 w-3.5" />
              </button>
              {copied === 'iban' && <span className="text-xs text-green-500">✓</span>}
            </div>
          </div>
        )}
        <div className="pt-2 border-t border-border flex items-center justify-between">
          <span className="text-sm text-muted-foreground">المبلغ المطلوب</span>
          <span className="font-black text-foreground text-lg">
            {totals.remaining.toLocaleString('ar')} {invoice.currency || 'د.إ'}
          </span>
        </div>
        {invoice.invoice_number && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">مرجع التحويل</span>
            <div className="flex items-center gap-2">
              <span className="font-mono font-semibold text-foreground text-sm">{invoice.invoice_number}</span>
              <button onClick={() => copy(invoice.invoice_number, 'ref')} className="text-primary hover:text-primary/80">
                <Copy className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {officeSettings?.phone && (
        <a
          href={`https://wa.me/${officeSettings.phone.replace(/\D+/g, '')}?text=${encodeURIComponent(`مرحباً، قمت بتحويل مبلغ الفاتورة ${invoice.invoice_number || ''} بقيمة ${totals.remaining.toLocaleString()} ${invoice.currency || 'د.إ'}`)}`}
          target="_blank"
          rel="noreferrer"
          className="flex items-center justify-center gap-2 w-full h-11 rounded-xl bg-green-600 hover:bg-green-700 text-white text-sm font-semibold transition-colors"
        >
          <span>📱</span>أرسل إثبات التحويل عبر واتساب
        </a>
      )}
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// الصفحة الرئيسية للدفع
// ══════════════════════════════════════════════════════════════════════════════
export default function Payment() {
  const [invoice,       setInvoice]       = useState(null)
  const [officeSettings,setOfficeSettings] = useState(null)
  const [loading,       setLoading]       = useState(true)
  const [error,         setError]         = useState('')
  const [paymentMethod, setPaymentMethod] = useState('card') // 'card' | 'bank'
  const [clientSecret,  setClientSecret]  = useState(null)
  const [stripePromise, setStripePromise] = useState(null)
  const [paid,          setPaid]          = useState(false)
  const [loadingIntent, setLoadingIntent] = useState(false)
  const [intentError,   setIntentError]   = useState('')

  // استخراج token من الـ URL
  const token   = new URLSearchParams(window.location.search).get('token')
  const paidParam = new URLSearchParams(window.location.search).get('paid')
  const invParam  = new URLSearchParams(window.location.search).get('inv')

  useEffect(() => {
    if (paidParam === '1') { setPaid(true); return }
    if (!token)            { setError('رابط الدفع غير صالح.'); setLoading(false); return }
    loadInvoice()
  }, [token, paidParam])

  const loadInvoice = useCallback(async () => {
    setLoading(true)
    try {
      const parsed = parsePaymentToken(token)
      if (!parsed?.id) throw new Error('رابط منتهي الصلاحية أو غير صالح.')

      const [invoices, settings] = await Promise.all([
        base44.entities.Invoice.filter({ id: parsed.id }, null, 1),
        base44.entities.OfficeSettings.list(),
      ])

      const inv = invoices?.[0]
      if (!inv) throw new Error('لم يتم العثور على الفاتورة.')

      setInvoice(inv)
      setOfficeSettings(settings?.[0] || null)

      // تحميل Stripe إذا كان المفتاح موجوداً
      const pubKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || settings?.[0]?.stripe_publishable_key
      if (pubKey) {
        setStripePromise(loadStripe(pubKey))
      }
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [token])

  // تحديث حالة الفاتورة بعد الدفع
  useEffect(() => {
    if (paid && invParam) {
      base44.entities.Invoice.update(invParam, { status: 'مدفوعة' }).catch(() => {})
    }
  }, [paid, invParam])

  const createPaymentIntent = useCallback(async () => {
    if (!invoice || clientSecret) return
    setLoadingIntent(true)
    setIntentError('')
    try {
      const { remaining } = getInvoiceTotals(invoice)
      const { data, error } = await supabase.functions.invoke('create-payment-intent', {
        body: {
          amount      : remaining,
          currency    : (invoice.currency || 'AED').toLowerCase(),
          invoice_id  : invoice.id,
          client_name : invoice.client_name,
          description : `فاتورة ${invoice.invoice_number || invoice.id}`,
        },
      })
      if (error) throw new Error(error.message)
      if (data?.error) throw new Error(data.error)
      setClientSecret(data.client_secret)
    } catch (err) {
      setIntentError(err.message || 'تعذر تحضير نافذة الدفع.')
    } finally {
      setLoadingIntent(false)
    }
  }, [invoice, clientSecret])

  useEffect(() => {
    if (invoice && paymentMethod === 'card' && !clientSecret && stripePromise) {
      createPaymentIntent()
    }
  }, [invoice, paymentMethod, stripePromise, clientSecret])

  // ── حالات التحميل / الخطأ / النجاح ──────────────────────────────────────
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-4">
        <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto" />
        <p className="text-muted-foreground">جارٍ تحميل بيانات الفاتورة…</p>
      </div>
    </div>
  )

  if (paid) return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4" dir="rtl">
      <Card className="w-full max-w-md p-8 text-center space-y-4">
        <div className="h-16 w-16 rounded-full bg-green-500/15 flex items-center justify-center mx-auto">
          <CheckCircle2 className="h-8 w-8 text-green-500" />
        </div>
        <h1 className="text-2xl font-black text-foreground">تم الدفع بنجاح! 🎉</h1>
        <p className="text-muted-foreground">شكراً لك. تم استلام دفعتك وسيصلك تأكيد قريباً.</p>
        {officeSettings?.phone && (
          <p className="text-sm text-muted-foreground">
            للاستفسار: <span className="font-semibold text-foreground">{officeSettings.phone}</span>
          </p>
        )}
      </Card>
    </div>
  )

  if (error) return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4" dir="rtl">
      <Card className="w-full max-w-md p-8 text-center space-y-4">
        <AlertCircle className="h-12 w-12 text-destructive mx-auto" />
        <h1 className="text-xl font-bold text-foreground">تعذر فتح رابط الدفع</h1>
        <p className="text-muted-foreground">{error}</p>
      </Card>
    </div>
  )

  const totals = getInvoiceTotals(invoice)
  const alreadyPaid = invoice.status === 'مدفوعة' || totals.remaining <= 0

  return (
    <div className="min-h-screen bg-background flex flex-col items-center py-8 px-4" dir="rtl">

      {/* ── Header المكتب ─────────────────────────────────────────────────── */}
      <div className="w-full max-w-lg mb-6">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Landmark className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="font-bold text-foreground">{officeSettings?.office_name || 'المكتب القانوني'}</p>
            <p className="text-xs text-muted-foreground">{officeSettings?.lawyer_name || ''}</p>
          </div>
        </div>
      </div>

      {/* ── بطاقة ملخص الفاتورة ───────────────────────────────────────────── */}
      <Card className="w-full max-w-lg p-5 mb-5">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <Receipt className="h-5 w-5 text-primary" />
              <h2 className="font-bold text-foreground">
                فاتورة {invoice.invoice_number || ''}
              </h2>
            </div>
            <p className="text-sm text-muted-foreground mt-0.5">{invoice.client_name}</p>
            {invoice.case_title && <p className="text-xs text-muted-foreground">{invoice.case_title}</p>}
          </div>
          <Badge className={
            alreadyPaid ? 'bg-green-500/10 text-green-600 border-green-500/20' :
            invoice.status === 'متأخرة' ? 'bg-destructive/10 text-destructive border-destructive/20' :
            'bg-primary/10 text-primary border-primary/20'
          }>
            {invoice.status}
          </Badge>
        </div>

        <div className="grid grid-cols-3 gap-3 bg-muted/30 rounded-2xl p-4">
          {[
            { label: 'الإجمالي',  value: totals.total.toLocaleString('ar') },
            { label: 'المدفوع',   value: totals.paid.toLocaleString('ar'),   color: 'text-green-500' },
            { label: 'المستحق',   value: totals.remaining.toLocaleString('ar'), color: 'text-primary font-black' },
          ].map((item, i) => (
            <div key={i} className="text-center">
              <p className="text-xs text-muted-foreground mb-1">{item.label}</p>
              <p className={`font-bold text-foreground ${item.color || ''}`}>
                {item.value} <span className="text-xs font-normal">{invoice.currency || 'د.إ'}</span>
              </p>
            </div>
          ))}
        </div>
      </Card>

      {/* ── الدفع ────────────────────────────────────────────────────────── */}
      <Card className="w-full max-w-lg p-5">

        {alreadyPaid ? (
          <div className="text-center py-6 space-y-3">
            <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto" />
            <p className="font-bold text-foreground text-lg">تم سداد هذه الفاتورة</p>
            <p className="text-sm text-muted-foreground">شكراً لك على الدفع في الوقت المحدد.</p>
          </div>
        ) : (
          <>
            {/* اختيار طريقة الدفع */}
            <div className="flex gap-2 mb-5 p-1 bg-muted/40 rounded-2xl">
              <button
                onClick={() => setPaymentMethod('card')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all ${paymentMethod === 'card' ? 'bg-card shadow text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                <CreditCard className="h-4 w-4" />
                بطاقة / محفظة رقمية
              </button>
              <button
                onClick={() => setPaymentMethod('bank')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all ${paymentMethod === 'bank' ? 'bg-card shadow text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                <Banknote className="h-4 w-4" />
                تحويل بنكي
              </button>
            </div>

            {/* محتوى طريقة الدفع */}
            {paymentMethod === 'card' && (
              <>
                {!stripePromise && (
                  <div className="text-center py-6 space-y-3">
                    <CreditCard className="h-10 w-10 text-muted-foreground mx-auto opacity-40" />
                    <p className="text-sm font-semibold text-foreground">الدفع بالبطاقة غير مُفعَّل</p>
                    <p className="text-xs text-muted-foreground">يرجى التواصل مع المكتب لإعداد بوابة الدفع.</p>
                    <button
                      onClick={() => setPaymentMethod('bank')}
                      className="text-sm text-primary underline underline-offset-2"
                    >
                      استخدم التحويل البنكي بدلاً من ذلك
                    </button>
                  </div>
                )}
                {stripePromise && !clientSecret && loadingIntent && (
                  <div className="flex items-center justify-center py-8 gap-3 text-sm text-muted-foreground">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    جارٍ تجهيز نافذة الدفع…
                  </div>
                )}
                {stripePromise && !clientSecret && intentError && (
                  <div className="space-y-3">
                    <div className="flex items-start gap-2 p-3 rounded-xl bg-destructive/10 text-destructive text-sm">
                      <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                      {intentError}
                    </div>
                    <button onClick={createPaymentIntent} className="w-full h-10 rounded-xl border border-border text-sm text-foreground hover:bg-muted/50">
                      إعادة المحاولة
                    </button>
                  </div>
                )}
                {stripePromise && clientSecret && (
                  <Elements
                    stripe={stripePromise}
                    options={{ clientSecret, appearance: STRIPE_APPEARANCE, locale: 'ar' }}
                  >
                    <CardPaymentForm
                      clientSecret={clientSecret}
                      invoice={invoice}
                      totals={totals}
                      onSuccess={() => setPaid(true)}
                    />
                  </Elements>
                )}
              </>
            )}

            {paymentMethod === 'bank' && (
              <BankTransferSection
                invoice={invoice}
                officeSettings={officeSettings}
                totals={totals}
              />
            )}

            {/* ── طرق الدفع المقبولة ── */}
            <div className="mt-5 pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground text-center mb-3">طرق الدفع المقبولة</p>
              <div className="flex items-center justify-center gap-3 flex-wrap">
                {[
                  { label: 'Visa',         emoji: '💳' },
                  { label: 'Mastercard',   emoji: '💳' },
                  { label: 'Apple Pay',    emoji: '🍎' },
                  { label: 'Google Pay',   emoji: '🔷' },
                  { label: 'تحويل بنكي',  emoji: '🏦' },
                ].map((m, i) => (
                  <span key={i} className="flex items-center gap-1 text-xs bg-muted/50 border border-border rounded-lg px-2.5 py-1 text-muted-foreground">
                    {m.emoji} {m.label}
                  </span>
                ))}
              </div>
            </div>
          </>
        )}
      </Card>

      {/* Footer */}
      <p className="mt-6 text-xs text-muted-foreground flex items-center gap-1.5">
        <Shield className="h-3.5 w-3.5 text-green-500" />
        مدفوعاتك محمية بتشفير SSL — مدعوم بـ Stripe
      </p>
    </div>
  )
}
